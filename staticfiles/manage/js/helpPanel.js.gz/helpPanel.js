function displayTipPanel() {
  document.getElementById("help_display").innerHTML = "Hello World";
}

function displayTipPanel2() {
  document.getElementById("help_display").innerHTML = "Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2Hello World 2";
}